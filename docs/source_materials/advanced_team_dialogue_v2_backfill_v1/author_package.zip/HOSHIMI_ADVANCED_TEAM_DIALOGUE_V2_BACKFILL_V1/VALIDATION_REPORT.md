# Advanced OR Team Dialogue V2 — Backfill Validation Report

**Result:** PASS (authoring/static only)  
**Scope:** 6 procedures / 73 stages / 292 new bilingual dialogue entries  
**No runtime tests performed.**

| Procedure ID | Stages | P | S | V2 spoken lines | 3/4/5-line nodes | V1 stage variants unchanged | V1 P feedback unchanged |
|---|---:|---:|---:|---:|---:|---:|---:|
| `surgery_open_whipple` | 13 | 6 | 2 | 52 | 2/9/2 | not supplied | not supplied |
| `surgery_adv_pelvic_sidewall_tumor_vascular_reconstruction` | 12 | 6 | 2 | 48 | 2/8/2 | 31 | 12 |
| `surgery_adv_sleeve_lobectomy` | 11 | 5 | 2 | 44 | 2/7/2 | 28 | 10 |
| `surgery_adv_ebstein_cone_reconstruction` | 13 | 6 | 2 | 52 | 2/9/2 | 34 | 12 |
| `surgery_adv_complex_abdominal_reconstruction` | 12 | 6 | 2 | 48 | 2/8/2 | 24 | 12 |
| `surgery_adv_open_descending_thoracic_aortic_replacement` | 12 | 6 | 2 | 48 | 2/8/2 | 24 | 12 |

**Checks:** stage IDs/ordering, expected line quotas, legal job roles, bilingual non-empty text, no Day2 named patient lines, unique line IDs, P/S counts, and the five supplied legacy V1 baselines (read-only).

**Whipple exception:** Its actual current `dialogue/surgery_open_whipple.json` was not in the supplied Library content. W01–W13 were cross-checked against the Whipple standalone handoff and full physiology P0 document; Codex must reconcile stage IDs with the live repository before merging. This package does not replace that legacy file.

**V2 schema exception:** `advanced_day2_dialogue_v2_proposed` is a content interchange label, not an existing Godot loader schema. The V2 loader/rendering API needs explicit review and implementation.

**Clinical caveat:** The operative dialogue has been reviewed against the procedures and accessible medical sources, but no clinical specialist has approved it for real patient care. This is fiction/game content.

## Legacy V1 SHA-256 checksums (reference only)

- `surgery_adv_pelvic_sidewall_tumor_vascular_reconstruction`: `ff232d6d72d9f872020fc21ad9b9a2a4e3cbb03ea8105ff5b580b000f079f8f3`
- `surgery_adv_sleeve_lobectomy`: `0ff152e3e2eb92bd30a11d83d2fc92039e2520deb04e6a23d60e4da8e2d384de`
- `surgery_adv_ebstein_cone_reconstruction`: `ccb9954aea81b05a4c1d41cc4107c4bce01ecf8f855be9dceaa420893c1c37b1`
- `surgery_adv_complex_abdominal_reconstruction`: `f553df7708f1f6bc56246f4ec4b610221236af6f52f43e2c560b207ac159b806`
- `surgery_adv_open_descending_thoracic_aortic_replacement`: `3849b0016e167fce7e42e16f889cca86d1d255699b953ab011683a6b9f881add`

## Failures

None in static authoring validation.
