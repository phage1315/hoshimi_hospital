#!/usr/bin/env node
// Authoring-data builder only. These overlays are NOT currently a registered Godot schema.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const pack = path.dirname(here);
const sourceRoot = path.dirname(pack);
const authored = path.join(pack, 'authored');
const outputDir = path.join(pack, 'dialogue_v2');
const failures = [];
const check = (cond, message) => { if (!cond) failures.push(message); };
const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');

const caseDir = path.join(sourceRoot, 'HOSHIMI_ADVANCED_THREE_CASES_CONTENT_V1');
const izumiDir = path.join(sourceRoot, 'HOSHIMI_ADVANCED_IZUMI_MISA_CONTENT_V1');
const sources = [
  {source: 'THREE_CASES_CONTENT_V1', dir: caseDir},
  {source: 'IZUMI_MISA_CONTENT_V1', dir: izumiDir},
];
const byId = new Map();
for (const group of sources) {
  const procedures = json(path.join(group.dir, 'procedures_additions.json'));
  for (const procedure of procedures) {
    check(!byId.has(procedure.id), `Duplicate procedure ID in baseline: ${procedure.id}`);
    const previous = path.join(group.dir, 'dialogue', `${procedure.id}.json`);
    const v1 = json(previous);
    check(v1.procedure_id === procedure.id, `V1 dialogue ID mismatch: ${procedure.id}`);
    check(v1.schema_version === 'advanced_day2_dialogue_v1', `Wrong baseline schema: ${procedure.id}`);
    const stageIds = procedure.steps.map(s => s.id);
    check(JSON.stringify(Object.keys(v1.stages)) === JSON.stringify(stageIds), `Baseline V1 stage mismatch: ${procedure.id}`);
    for (const stage of procedure.steps) {
      const v1Node = v1.stages[stage.id];
      check(v1Node?.stage_entry?.length >= 2, `Baseline stage_entry missing: ${procedure.id}/${stage.id}`);
      if (stage.kind === 'P') check(v1Node?.precision_failed?.length >= 2, `Baseline P feedback missing: ${procedure.id}/${stage.id}`);
    }
    byId.set(procedure.id, {name: procedure.name, steps: procedure.steps.map(s => ({id:s.id, kind:s.kind, name:s.name})), source: group.source, v1, v1file:previous});
  }
}

// The Whipple V1 JSON itself was not available in Library; these 13 IDs and kinds
// were inspected in the actual Whipple standalone handoff and P0 physiology document.
const whippleId = 'surgery_open_whipple';
const whippleStages = [
  ['W01','F','切口与进入'],['W02','L','腹腔探查、建立暴露'],['W03','P','复杂粘连分离'],
  ['W04','S','主要血管关系与切除路径评估'],['W05','P','门静脉周围组织分离'],
  ['W06','P','胰头深部精细分离'],['W07','F','标本取出、整理术野'],
  ['W08','P','胰肠重建'],['W09','P','胆肠重建'],['W10','P','胃肠重建'],
  ['W11','S','重建区复核及止血'],['W12','L','最终清点与评估'],['W13','F','关闭'],
];
byId.set(whippleId, {name: '开腹胰十二指肠切除术（Whipple）', steps: whippleStages.map(([id,kind,name])=>({id,kind,name})), source:'WHIPPLE_STANDALONE_V1_AND_FULL_PHYSIOLOGY_P0',v1:null,v1file:null});

const expectedIds = [
  whippleId,
  'surgery_adv_pelvic_sidewall_tumor_vascular_reconstruction',
  'surgery_adv_sleeve_lobectomy',
  'surgery_adv_ebstein_cone_reconstruction',
  'surgery_adv_complex_abdominal_reconstruction',
  'surgery_adv_open_descending_thoracic_aortic_replacement',
];
const allowedRoles = new Set(['lead_surgeon','assistant_1','assistant_2','scrub_primary','scrub_secondary','circulating_primary','circulating_secondary','anesthesia','system']);
const stageOrder = new Map(expectedIds.map(pid=>[pid,byId.get(pid).steps.map(s=>s.id)]));
const metrics = [];
const review = [
  '# Advanced OR Team Dialogue V2 — 六台既有术式中文审稿版',
  '',
  '> 从 `authored/*.psv` 机械生成；仅为 Day 2 专业团队对白，不含患者清醒对白。',
  '> 每阶段按照「操作前→玩家操作→解决后」演出。危机和 Precision 失败另走现有流程。',
  '',
];
let totalLines = 0;
let totalStages = 0;
const allLineIds = new Set();

fs.mkdirSync(outputDir, {recursive:true});
for (const id of expectedIds) {
  const baseline = byId.get(id);
  check(!!baseline, `Missing baseline procedure ${id}`);
  if (!baseline) continue;
  const file = path.join(authored, `${id}.psv`);
  check(fs.existsSync(file), `Missing authored file ${file}`);
  if (!fs.existsSync(file)) continue;
  const entries = new Map();
  const counts = Object.fromEntries([...allowedRoles].map(role=>[role,0]));
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    if (!raw.trim() || raw.startsWith('#')) continue;
    const parts = raw.split('|');
    check(parts.length === 5, `Expected 5 pipe-separated columns: ${id} ${raw.slice(0,60)}`);
    if (parts.length !== 5) continue;
    const [stageId,phase,role,zh,en] = parts;
    check(allowedRoles.has(role) && role !== 'system', `Invalid spoken role ${id}/${stageId}/${role}`);
    check(['before_action','after_resolution'].includes(phase), `Invalid phase ${id}/${stageId}/${phase}`);
    check(zh.length >= 14 && zh.length <= 120, `Chinese line outside review range ${id}/${stageId}: ${zh.length}`);
    check(en.length >= 25 && en.length <= 260, `English line outside review range ${id}/${stageId}: ${en.length}`);
    check(!/[|\n\r]/.test(zh+en), `Unsafe line delimiter ${id}/${stageId}`);
    check(!/(伊兹米|美纱|濑津美|里香|菜穗子|樱良|佩特拉)/.test(zh), `Named patient in Day2 ${id}/${stageId}`);
    const bundle = entries.get(stageId) ?? {before_action: [],after_resolution: []};
    if (!bundle[phase]) continue;
    const n = bundle[phase].length + 1;
    const short = phase === 'before_action' ? 'PRE' : 'POST';
    const lineId = `${stageId}_V2_${short}${String(n).padStart(2,'0')}`;
    check(!allLineIds.has(`${id}/${lineId}`), `Duplicate line ID ${id}/${lineId}`);
    allLineIds.add(`${id}/${lineId}`);
    bundle[phase].push({id:lineId,speaker_role:role,text:zh,text_en:en});
    entries.set(stageId,bundle);
    counts[role]++;
  }
  const stages = {};
  for (const sid of stageOrder.get(id)) {
    const node = entries.get(sid);
    check(!!node, `Missing V2 stage ${id}/${sid}`);
    if (!node) continue;
    check(node.before_action.length >= 2 && node.before_action.length <= 3, `Expected 2-3 PRE lines ${id}/${sid}`);
    check(node.after_resolution.length >= 1 && node.after_resolution.length <= 2, `Expected 1-2 POST lines ${id}/${sid}`);
    check(node.before_action.length + node.after_resolution.length >= 3 && node.before_action.length + node.after_resolution.length <= 5, `V2 quota failed ${id}/${sid}`);
    stages[sid] = node;
  }
  check(entries.size === baseline.steps.length, `Extra or missing authored stage ${id}: ${entries.size} vs ${baseline.steps.length}`);
  for (const sid of entries.keys()) check(stageOrder.get(id).includes(sid), `Unknown stage ${id}/${sid}`);
  for (const role of ['assistant_1','assistant_2','scrub_primary','scrub_secondary','circulating_primary','circulating_secondary','anesthesia','lead_surgeon']) check(counts[role]>0, `Team role not represented in ${id}: ${role}`);
  const output = {schema_version:'advanced_day2_dialogue_v2_proposed',procedure_id:id,stages};
  fs.writeFileSync(path.join(outputDir,`${id}.json`),JSON.stringify(output,null,2)+'\n','utf8');
  review.push(`## ${baseline.name}`, '', `Procedure ID: \`${id}\``, '');
  for (const step of baseline.steps) {
    const node = stages[step.id];
    if (!node) continue;
    review.push(`### ${step.id} ${step.name}（${step.kind}）`, '', '**操作前**', '');
    for (const line of node.before_action) review.push(`- \`${line.speaker_role}\`：「${line.text}」`);
    review.push('', '**节点完成后**', '');
    for (const line of node.after_resolution) review.push(`- \`${line.speaker_role}\`：「${line.text}」`);
    review.push('');
  }
  const oldVariants = baseline.v1 ? Object.values(baseline.v1.stages).reduce((n,s)=>n+s.stage_entry.length,0) : null;
  const oldPrecision = baseline.v1 ? Object.values(baseline.v1.stages).reduce((n,s)=>n+(s.precision_failed?.length??0),0) : null;
  const lengths = Object.values(stages).map(s=>s.before_action.length+s.after_resolution.length);
  const datum = {id,name:baseline.name,source:baseline.source,stages:baseline.steps.length,precision:baseline.steps.filter(s=>s.kind==='P').length,strategy:baseline.steps.filter(s=>s.kind==='S').length,v2Lines:lengths.reduce((n,v)=>n+v,0),stageQuotaDistribution:{three:lengths.filter(n=>n===3).length,four:lengths.filter(n=>n===4).length,five:lengths.filter(n=>n===5).length},roleCounts:counts,v1EntryVariants:oldVariants,v1FailedVariants:oldPrecision,v1Sha256:baseline.v1file?sha(baseline.v1file):null};
  metrics.push(datum);
  totalLines += datum.v2Lines;
  totalStages += datum.stages;
}
check(totalStages===73,`Expected 73 stages, got ${totalStages}`);
check(totalLines===292,`Expected 292 lines, got ${totalLines}`);
check(metrics.length===6,`Expected 6 procedures, got ${metrics.length}`);
fs.writeFileSync(path.join(pack,'STAGE_REVIEW_CN.md'),review.join('\n')+'\n','utf8');

const status = failures.length ? 'FAILED' : 'PASS (authoring/static only)';
const stamp = '# Advanced OR Team Dialogue V2 — Backfill Validation Report\n\n'
  + `**Result:** ${status}  \n**Scope:** ${metrics.length} procedures / ${totalStages} stages / ${totalLines} new bilingual dialogue entries  \n**No runtime tests performed.**\n\n`
  + '| Procedure ID | Stages | P | S | V2 spoken lines | 3/4/5-line nodes | V1 stage variants unchanged | V1 P feedback unchanged |\n|---|---:|---:|---:|---:|---:|---:|---:|\n'
  + metrics.map(m=>`| \`${m.id}\` | ${m.stages} | ${m.precision} | ${m.strategy} | ${m.v2Lines} | ${m.stageQuotaDistribution.three}/${m.stageQuotaDistribution.four}/${m.stageQuotaDistribution.five} | ${m.v1EntryVariants??'not supplied'} | ${m.v1FailedVariants??'not supplied'} |`).join('\n')+'\n\n'
  + '**Checks:** stage IDs/ordering, expected line quotas, legal job roles, bilingual non-empty text, no Day2 named patient lines, unique line IDs, P/S counts, and the five supplied legacy V1 baselines (read-only).\n\n'
  + '**Whipple exception:** Its actual current `dialogue/surgery_open_whipple.json` was not in the supplied Library content. W01–W13 were cross-checked against the Whipple standalone handoff and full physiology P0 document; Codex must reconcile stage IDs with the live repository before merging. This package does not replace that legacy file.\n\n'
  + '**V2 schema exception:** `advanced_day2_dialogue_v2_proposed` is a content interchange label, not an existing Godot loader schema. The V2 loader/rendering API needs explicit review and implementation.\n\n'
  + '**Clinical caveat:** The operative dialogue has been reviewed against the procedures and accessible medical sources, but no clinical specialist has approved it for real patient care. This is fiction/game content.\n\n'
  + '## Legacy V1 SHA-256 checksums (reference only)\n\n'
  + metrics.filter(m=>m.v1Sha256).map(m=>`- \`${m.id}\`: \`${m.v1Sha256}\``).join('\n')+'\n\n'
  + (failures.length ? `## Failures\n\n${failures.map(x=>'- '+x).join('\n')}\n` : '## Failures\n\nNone in static authoring validation.\n');
fs.writeFileSync(path.join(pack,'VALIDATION_REPORT.md'),stamp,'utf8');
console.log(JSON.stringify({status,procedures:metrics.length,stages:totalStages,lines:totalLines,perProcedure:metrics.map(({id,stages,v2Lines})=>({id,stages,v2Lines})),failures},null,2));
if (failures.length) process.exitCode=1;
