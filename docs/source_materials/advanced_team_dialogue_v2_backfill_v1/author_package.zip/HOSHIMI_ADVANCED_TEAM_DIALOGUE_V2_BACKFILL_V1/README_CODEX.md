# Hoshimi Hospital — 既有六台 Advanced OR Team Dialogue V2 Backfill V1

**状态：作者内容交付／静态数据通过；尚未并入 Godot，也不代表 V2 播放器已实装。**  
**制作日期：2026-11-02／03（按项目本地工作周期）。**  
**用途：** 在佩特拉 V2 试点尚在体验测试时，提前为所有已知六台旧高级术式写完连续团队对白；后续可按作者的体验意见再调节节奏。  
**源规范：** `HOSHIMI_ADVANCED_OR_TEAM_DIALOGUE_V2_SPEC.md`，Library 原文件保持不动。

## 1. 完成范围

| 术式 | procedure_id | 阶段 | 新 V2 对白 |
|---|---|---:|---:|
| Whipple 胰十二指肠切除 | `surgery_open_whipple` | 13 | 52 |
| 盆壁肿瘤切除及髂血管重建 | `surgery_adv_pelvic_sidewall_tumor_vascular_reconstruction` | 12 | 48 |
| 开胸袖式肺叶切除及本例肺动脉重建 | `surgery_adv_sleeve_lobectomy` | 11 | 44 |
| Ebstein 畸形 Cone 三尖瓣重建 | `surgery_adv_ebstein_cone_reconstruction` | 13 | 52 |
| 伊兹米：复杂腹腔黏连松解与多脏器修复 | `surgery_adv_complex_abdominal_reconstruction` | 12 | 48 |
| 美纱：开胸降主动脉置换、重要肋间动脉重接 | `surgery_adv_open_descending_thoracic_aortic_replacement` | 12 | 48 |
| **合计** | **6** | **73** | **292** |

每个手术节点 3–5 句、先后次序固定，具体采用 **2／3 句操作前 + 1／2 句节点完成后**；不让每阶段都机械地恰好四句。每台有两个 3 句节点和两个 5 句高价值节点，其余是四句节点。中文和英文逐句配对，角色均是岗位 ID；两名助手、器械、巡回、麻醉与主刀在整个手术内实际分工。

## 2. 文件结构

- `dialogue_v2/<procedure_id>.json` ×6：独立的 V2 **建议格式**，只含新连续对白，方便工程合并或转换。
- `authored/<procedure_id>.psv` ×6：逐句作者原稿，`stage|phase|role|text|text_en`；将来修改请改此处再生成 JSON。
- `STAGE_REVIEW_CN.md`：按术式、stage、操作前/完成后排列的中文可读审稿稿。
- `tools/build_and_validate.mjs`：从原稿生成六份 JSON 和审稿稿、验证 stage ID/角色/中英文本，核对源包五份旧 V1 对白文件。
- `VALIDATION_REPORT.md`：静态验收结果、逐术式数字以及旧 V1 参考哈希。

生成和重验：在与两份解包的源内容文件夹同级位置，执行 `node HOSHIMI_ADVANCED_TEAM_DIALOGUE_V2_BACKFILL_V1/tools/build_and_validate.mjs`。交付 ZIP 没有包含旧源包；若要在独立机器上重跑，请先将下述两份源 ZIP 解包放在本包父目录，或让 Codex 把路径改成真实仓库基线。**交付的六份 JSON 本身已经生成并通过独立校验。**

## 3. 原有 V1 资料与内容锁

源资料已实际读取：

- `HOSHIMI_ADVANCED_THREE_CASES_CONTENT_V1.zip`：盆壁 12、袖式肺叶 11、Ebstein Cone 13 个阶段，以及原 `advanced_day2_dialogue_v1` 数据。
- `HOSHIMI_ADVANCED_IZUMI_MISA_CONTENT_V1.zip`：伊兹米和美纱各 12 阶段，以及原 `advanced_day2_dialogue_v1` 数据。
- `HOSHIMI_ADVANCED_SURGERY_STANDALONE_CODEX_READY_V1.md` 与 `HOSHIMI_ADVANCED_WHIPPLE_FULL_PHYSIOLOGY_STRATEGY_CODEX_P0_V1.md`：Whipple W01–W13、6P/2S、W05/W10 危机关口。
- `advanced_surgery_dialogue_gaps_2026-10-31.md`：当前 V1 单阶段随机台词、Time-out 工作与终末对白的独立缺口说明。**那些既有角色专属 Time-out 缺口不属于本次 V2 节点 backfill。**

**没有修改旧 ZIP、V1 JSON、患者 Day 1/Day 3 故事、美术 manifest、HP、Precision、Strategy、危机数值或任何已有已批准原文。** 原有 `stage_entry` 及 `precision_failed` 必须保持在原数据内；V2 正常连续对白不是把 V1 的随机候选数组串起来念。

Whipple 的 **当前真实** `dialogue/surgery_open_whipple.json` 未出现在本次可读取的 Library 源交接文件中；本包只与已核实 W01–W13 技术规格对齐，**接入前必须拿真实仓库 Whipple 对白和注册数据比对**，不能假定已经完成工程对齐。

注意旧三台内容包中袖式肺叶首发患者的具体人物仍有候选待确认说明；这不影响本台符合原有 T09「肺动脉重建」的 Day 2 技术对白。本包不触碰首发患者安排，也不为普通返场自动赋予特殊首发背景。

## 4. 给 Codex 的集成建议（需要先审计 Runner）

1. 先定位真实 `advanced_operative_dialogue.gd`、Advanced Runner stage UI、角色岗位绑定和正在使用的 V1 JSON。核对每台实际 procedure_id、stage ID 和 kind；如果真实数据与本包不同，**停止对应术式的自动合并，报告差异**。
2. `schema_version: "advanced_day2_dialogue_v2_proposed"` 只是**内容交换标签，未获 Godot 注册**。实现时应在现有 loader/renderer 上加入**可选**的顺序 `before_action` 和 `after_resolution`，确认真实生产 schema 名称后再转换数据。禁止把 `v2_proposed` 直接视为已存在的正式版本。
3. **推荐兼容优先级**：当前阶段若有完整且合法的 V2 序列，就依次显示 V2；否则保持 V1 `stage_entry` 原有「随机选一条」行为。**同一阶段不要同时播放 V1 单句和 V2 四句，避免重复。** 完成顺序：阶段进入→V2 before→原 F/L/S/P 操作→合法非终止解决后 V2 after→下阶段。
4. Precision 失败、助手救援、既有危机、HP/生理终止具有优先权；终止性失败不播放“已完成”式 after。S 节点仍由玩家决定方案，台词不得替玩家选择。危机条件与生理值由现有引擎提供；这些静态台词**不宣称具体失血量、用血袋数、血压、监测必然正常或术中永久损伤**。
5. `speaker_role` 绑定本次 Grand OR roster，不能显示未编组人员。短对白自动播放、支持快进/整组跳过、避免重复触发；不要增加玩家每阶段的确认点击、独立 RNG、库存系统或长期存档字段。
6. 通过真实的功能测试：每个 stage 进入一次，P 失败／救援／危机插入／Game Over、S 选择、切换中英文本、任意合法编组、重入 UI、首次成功/失败、CLEARED 后返场、助手14日冷却、Ordinary 回归。**不得将静态数据 PASS 写成 Godot 测试 PASS。**

## 5. V2 片段格式示例

```json
{
  "schema_version": "advanced_day2_dialogue_v2_proposed",
  "procedure_id": "surgery_open_whipple",
  "stages": {
    "W01": {
      "before_action": [
        {"id": "W01_V2_PRE01", "speaker_role": "assistant_2", "text": "切口线和上腹部牵开方向核对过了，我负责保持腹壁张力。", "text_en": "The incision line and upper abdominal retraction are confirmed. I'll maintain the abdominal wall tension."}
      ],
      "after_resolution": [
        {"id": "W01_V2_POST01", "speaker_role": "assistant_1", "text": "腹壁层次已经打开，先别急着深牵，下面还有可能贴着肠袢。", "text_en": "The abdominal wall is open. Hold the deep retraction; bowel loops may be adherent underneath."}
      ]
    }
  }
}
```

示例仅显示 W01 的一部分；**真实完整数据请用 `dialogue_v2/surgery_open_whipple.json`**。

## 6. 医学依据与内容抽象

所写内容对应六类真实手术中的常见团队任务，但均为《星见医院》游戏抽象，不是具体患者的医疗指导：

- Whipple 三处消化道重建：<https://pmc.ncbi.nlm.nih.gov/articles/PMC9584030/>
- 复杂盆壁肿瘤切除的输尿管/神经/血管保护：<https://pmc.ncbi.nlm.nih.gov/articles/PMC7500962/>
- 支气管袖式切除联合必要时肺动脉重建：<https://pmc.ncbi.nlm.nih.gov/articles/PMC4775260/>
- Ebstein Cone 解剖、瓣叶游离与右室折叠：<https://pmc.ncbi.nlm.nih.gov/articles/PMC8305696/>
- 复杂腹腔黏连的肠壁损伤风险与目标性松解：<https://pmc.ncbi.nlm.nih.gov/articles/PMC4807323/>
- 胸降主动脉开放置换的肋间动脉保护与脊髓灌注：<https://pmc.ncbi.nlm.nih.gov/articles/PMC11518943/>

## 7. 与佩特拉试点的关系

佩特拉的创伤后胸腰椎 PVCR 是**单独 V2 首发试点**，不在此六台 backfill 内。本包先把旧术式的文字准备好；是否立即接入这些历史病例、是否调整自动播放速度，等佩特拉在 Godot 的实际体验确定。若新体验要求更短的过场，优先调整统一播放时序，而不是无理由删减已批准的手术实质信息。
